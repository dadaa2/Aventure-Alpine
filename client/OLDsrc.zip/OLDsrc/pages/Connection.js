import React from 'react'

function Connection() {
  return (
    <div>Connection</div>
  )
}

export default Connection