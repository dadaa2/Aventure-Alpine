import React from 'react'

function Article() {
  return (
    <div>Article</div>
  )
}

export default Article